/*
  ******************************************************************************
  * @file    apt32f101_EPT.h
  * @author  APT AE Team
  * @version V1.0
  * @date    2016/07/19
  ******************************************************************************
  *THIS SOFTWARE WHICH IS FOR ILLUSTRATIVE PURPOSES ONLY WHICH PROVIDES 
  *CUSTOMER WITH CODING INFORMATION REGARDING THEIR PRODUCTS.
  *APT CHIP SHALL NOT BE HELD RESPONSIBILITY ADN LIABILITY FOR ANY DIRECT, 
  *INDIRECT DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT OF 
  *SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION 
  *CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.AND APT CHIP RESERVES 
  *THE RIGHT TO MAKE CHANGES IN THE SOFTWARE WITHOUT NOTIFICATION
  ******************************************************************************
  */
  
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _apt32f101_EPT_H
#define _apt32f101_EPT_H

/* Includes ------------------------------------------------------------------*/
#include "apt32f101.h"

/******************************************************************************
************************* syscon Registers Definition *************************
******************************************************************************/
#define CORET_CSR_RST     	((CSP_REGISTER_T)0x00000004)
#define CORET_RVR_RST     	((CSP_REGISTER_T)0x00000000)
#define CORET_CVR_RST     	((CSP_REGISTER_T)0x00000000)
#define CORET_CALIB_RST     	((CSP_REGISTER_T)0x00000000)




extern void EPT_DeInit(void);
extern void EPT_Int_Enable(void);
extern void EPT_Int_Disable(void);
extern void  EPT_WakeUp_Enable(void);
extern void  EPT_WakeUp_Disable(void);
extern void EPT_start(void);
extern void EPT_stop(void);
extern void EPT_CLKSOURCE_EX(void);
extern void EPT_CLKSOURCE_IN(void);
extern void EPT_TICKINT_Enable(void);
extern void EPT_TICKINT_Disable(void);
extern void EPT_reload(void);

#endif   /**< apt32f101_syscon_H */

/******************* (C) COPYRIGHT 2016 APT Chip *****END OF FILE****/