/*
  ******************************************************************************
  * @file    apt32f101_tkey.c
  * @author  APT AE Team
  * @version V1.05
  * @date    2017/06/22
  ******************************************************************************
  *THIS SOFTWARE WHICH IS FOR ILLUSTRATIVE PURPOSES ONLY WHICH PROVIDES 
  *CUSTOMER WITH CODING INFORMATION REGARDING THEIR PRODUCTS.
  *APT CHIP SHALL NOT BE HELD RESPONSIBILITY ADN LIABILITY FOR ANY DIRECT, 
  *INDIRECT DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT OF 
  *SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION 
  *CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.AND APT CHIP RESERVES 
  *THE RIGHT TO MAKE CHANGES IN THE SOFTWARE WITHOUT NOTIFICATION
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "apt32f003_tkey.h"
#include "apt32f003_syscon.h"
/* -------define ------------------------------------------------------------*/
#define TK_RESET_VALUE	 0
/* -------Touch key parameter -----------------------------------------------*/
//#define TK_RC_Mode
#define TK_EX_Mode											//TK mode select

#define TK_IO_EN   	  	 0B000000000000110					//TK IO Enable,bit15←bit0=TCH15~TCH0 (no TK0,TK3,TK4,TK12)
#define	_Longress_time	 0									//longpress_time = (KEYSTICKDUR+1) x 16s
#if defined (TK_EX_Mode) || defined (TK_EX_Led_Mode)
    #define TK_Channel_EN    0B000000000000110				//TK channel set  HW
    #define	TK_GSR		     0x02							//gsr HW
#endif
#if defined (TK_RC_Mode) || defined (TK_RC_Led_Mode)
    #define TK_Channel_EN    0B000000000000110				//TK channel set  RC
    #define	TK_GSR		     0x02							//gsr RC
#endif	 
							//TK0 ,TK1, TK2, TK3 ,TK4 ,TK5 ,TK6 ,TK7 ,TK8 ,TK9 ,TK10,TK11,TK12,TK13,TK14,TK15
U32_T TK_Trigglevel_data[16]={0xFF,0x20,0x20,0xFF,0xFF,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0xFF,0x20,0x20,0xFF};   	
/* -------- variables ---------------------------------------------------------*/
volatile U8_T TK_MODE_FLAG;
int Key_Map,Noffset_cont,Noffset_cont1;
S32_T Sampling_Data[16];									//sampling data
S32_T Baseline_Data[16];									//baseline data
S32_T Offset_Data[16];										//offset data
/* Public functions ----------------------------------------------------------*/
/* Public functions ----------------------------------------------------------*/

/*************************************************************/
//Touch Register reset
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/  
void TK_DeInit(void)
{
    uint8_t i;
    for (i=0;i<16;i++)
    {
    TKEY->TCH_CHxCNT[i]  =TK_RESET_VALUE;
    TKEY->TCH_CHxBL[i]   =TK_RESET_VALUE;
    }
    TKEY->TCH_CR0       =TK_RESET_VALUE;
    TKEY->TCH_CR1       =TK_RESET_VALUE;
    TKEY->TCH_HWPCR0    =TK_RESET_VALUE;
    TKEY->TCH_HWPCR1    =TK_RESET_VALUE;
    TKEY->TCH_BLFUCR    =TK_RESET_VALUE;
    TKEY->TCH_START     =TK_RESET_VALUE;
    TKEY->TCH_SCTCR     =TK_RESET_VALUE;
    TKEY->TCH_CHDST     =TK_RESET_VALUE;
    TKEY->TCH_TSCCR     =TK_RESET_VALUE;
    TKEY->TCH_TSCDR     =TK_RESET_VALUE;
    TKEY->TCH_CHCFG     =TK_RESET_VALUE;
    TKEY->TCH_TSR       =TK_RESET_VALUE;
    TKEY->TCH_GSR       =TK_RESET_VALUE;
    TKEY->TCH_TKCR      =TK_RESET_VALUE;
    TKEY->TCH_RISR      =TK_RESET_VALUE;
    TKEY->TCH_IMCR      =TK_RESET_VALUE;
    TKEY->TCH_MISR      =TK_RESET_VALUE;
    TKEY->TCH_TKEYST    =TK_RESET_VALUE;
    TKEY->TCH_OSCR0     =TK_RESET_VALUE;
    TKEY->TCH_OSCR1     =TK_RESET_VALUE;
    TKEY->TCH_OSCR2     =TK_RESET_VALUE;
    TKEY->TCH_OSCR3     =TK_RESET_VALUE;
}
/*************************************************************/
//Touch IO Enable as touch key
//EntryParameter:TK_IOmode_xTK_IOmode_x
//TK_IOmode_x:ENLedShare,DISLedShare
//define by TK_Bit_EN:bitx=1 enable /bitx=0 disbale
/*************************************************************/  
void TK_IO_Enable(TK_IOmode_TypeDef TK_IOmode_x)
{
    uint8_t i;
	if(TK_IOmode_x==ENLedShare)
	{
		for (i=0;i<16;i++)
		{
			if ((TK_IO_EN & (1<<i))!=0)
			{
				switch (i)
				{
					case 0:GPIOA0->CONLR=(GPIOA0->CONLR&0XFFFFFFF0) | 0x00000009;break;
					case 1:GPIOA0->CONLR=(GPIOA0->CONLR&0XFFFFFF0F) | 0x00000090;break;
					case 2:GPIOA0->CONLR=(GPIOA0->CONLR&0XFFFFF0FF) | 0x00000900;break;
					case 3:GPIOB0->CONLR=(GPIOB0->CONLR&0XFFFFFFF0) | 0x00000009;break;
					case 4:GPIOB0->CONLR=(GPIOB0->CONLR&0XFFFFFF0F) | 0x00000090;break;
					case 5:GPIOA0->CONLR=(GPIOA0->CONLR&0XFFFF0FFF) | 0x00009000;break;
					case 6:GPIOA0->CONLR=(GPIOA0->CONLR&0XFFF0FFFF) | 0x00090000;break;
					case 7:GPIOA0->CONLR=(GPIOA0->CONLR&0XFF0FFFFF) | 0x00900000;break;
					case 8:GPIOA0->CONLR=(GPIOA0->CONLR&0XF0FFFFFF) | 0x09000000;break;
					case 9:break;
					case 10:break;
					case 11:break;
					case 12:break;
					case 13:GPIOB0->CONLR=(GPIOB0->CONLR&0XFFFF0FFF) | 0x00009000;break;
					case 14:GPIOB0->CONLR=(GPIOB0->CONLR&0XFFFFF0FF) | 0x00000900;break;
					case 15:GPIOA0->CONLR=(GPIOA0->CONLR&0X0FFFFFFF) | 0x90000000;break;
				}
			}
		}
	}
	else if(TK_IOmode_x==DISLedShare)
	{
		for (i=0;i<16;i++)
		{
			if ((TK_IO_EN & (1<<i))!=0)
			{
				switch (i)
				{
					case 0:GPIOA0->CONLR=(GPIOA0->CONLR&0XFFFFFFF0) | 0x00000009;break;
					case 1:GPIOA0->CONLR=(GPIOA0->CONLR&0XFFFFFF0F) | 0x00000090;break;
					case 2:GPIOA0->CONLR=(GPIOA0->CONLR&0XFFFFF0FF) | 0x00000900;break;
					case 3:GPIOB0->CONLR=(GPIOB0->CONLR&0XFFFFFFF0) | 0x00000009;break;
					case 4:GPIOB0->CONLR=(GPIOB0->CONLR&0XFFFFFF0F) | 0x00000090;break;
					case 5:GPIOA0->CONLR=(GPIOA0->CONLR&0XFFFF0FFF) | 0x00009000;break;
					case 6:GPIOA0->CONLR=(GPIOA0->CONLR&0XFFF0FFFF) | 0x00090000;break;
					case 7:GPIOA0->CONLR=(GPIOA0->CONLR&0XFF0FFFFF) | 0x00900000;break;
					case 8:GPIOA0->CONLR=(GPIOA0->CONLR&0XF0FFFFFF) | 0x09000000;break;
					case 9:GPIOA0->CONHR=(GPIOA0->CONHR&0XFFFF0FFF) | 0x00009000;break;
					case 10:GPIOA0->CONHR=(GPIOA0->CONHR&0XFFFFF0FF) | 0x00000900;break;
					case 11:GPIOA0->CONHR=(GPIOA0->CONHR&0XFFFFFF0F) | 0x00000090;break;
					case 12:GPIOA0->CONHR=(GPIOA0->CONHR&0XFFFFFFF0) | 0x00000009;break;
					case 13:GPIOB0->CONLR=(GPIOB0->CONLR&0XFFFF0FFF) | 0x00009000;break;
					case 14:GPIOB0->CONLR=(GPIOB0->CONLR&0XFFFFF0FF) | 0x00000900;break;
					case 15:GPIOA0->CONLR=(GPIOA0->CONLR&0X0FFFFFFF) | 0x90000000;break;
				}
			}
		}
	}
}
/*************************************************************/
//Touch IO Enable touch key fuction
//EntryParameter:NONE
//ReturnValue:NONE
//define by TK_CH_EN:bitx=1 enable /bitx=0 disbale
/*************************************************************/  
void TK_CH_Enable(void )
{
           TKEY->TCH_CHCFG = TK_Channel_EN;
}
/*************************************************************/
//Enable hardmacro IP
//EntryParameter:TK_ENABLE / TK_DISABLE
//ReturnValue:NONE
/*************************************************************/ 
void TK_HardMacro_Ctrl(TK_TKEN_TypeDef TKEN)
{
	TKEY->TCH_CR0 |= TKEN;
}
/*************************************************************/
//Enable hardmacro IP
//EntryParameter:TK_ENABLE / TK_DISABLE
//ReturnValue:NONE
/*************************************************************/ 
void TK_CLK_Ctrl(TK_CLKEN_TypeDef TKEN)
{
	 TKEY->TCH_CR0&=0xffff7f;
     TKEY->TCH_CR0 |= TKEN;
}
/*************************************************************/
//TK software reset
//EntryParameter:HM_Reset,AllTK_Reset
//ReturnValue:NONE
/*************************************************************/ 
void TK_software_reset(TK_software_TypeDef TK_Reset)
{
	TKEY->TCH_CR0|=TK_Reset;
	while(TKEY->TCH_CR0&(0x01<<3));
}

/*************************************************************/
//TK Rebuild
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/ 
void TK_Rebuild(void)
{
	TK_software_reset(HM_Reset);
	TK_CLK_Ctrl(CLK_ENABLE);
	while (TKEY->TCH_CR0 &(1<<3));
	TK_HardMacro_Ctrl(TK_ENABLE);   
	TK_Baseline_Config(TK_Channel_EN,0x0000);
	if(TK_MODE_FLAG)							//RC mode
	{
		TKEY->TCH_CR1 |= 0x01;
		TK_Start_Scan(ENABLE);
	}
	else										//EX mode
	{
		TK_Start_Scan(ENABLE);
		TK_Force_Rebuid();
	}
}
/*************************************************************/
//TK Rebuild
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/ 
void TK_CLKDIV_Change(TK_TKPDVI_TypeDef TKDIV)
{
	TK_Start_Scan(DISABLE);
	TK_CLK_Ctrl(CLK_DISABLE);
	TKEY->TCH_CR0&=0xff8fff;
	TKEY->TCH_CR0|=TKDIV;
	TK_CLK_Ctrl(CLK_ENABLE);
	while (TKEY->TCH_CR0 &(1<<3));
	TK_Baseline_Config(TK_Channel_EN,0x0000);
	if(TK_MODE_FLAG)							//RC mode
	{
		TKEY->TCH_CR1 |= 0x01;
		TK_Start_Scan(ENABLE);
	}
	else										//EX mode
	{
		TK_Start_Scan(ENABLE);
		TK_Force_Rebuid();
	}
}
/*************************************************************/
//TK Negative rebuild
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/ 
void TK_Negative_rebuild(void)
{
	S8_T i;
	if(TK_MODE_FLAG)							//RC mode
	{
		for(i=0;i<16;i++)
		{
			if((Offset_Data[i]<-TK_Trigglevel_data[i])&&(Baseline_Data[i]))
			{
				Noffset_cont++;
				if(Noffset_cont>=0x20)
				{
					  Noffset_cont=0;
					  TK_Rebuild();
				}
			}
		}
	}
	else										//RC mode
	{
		for(i=0;i<15;i++)
		{
			if((Offset_Data[i]<-TK_Trigglevel_data[i])&&(Baseline_Data[i]))
			{
				Noffset_cont++;
				if(Noffset_cont>=0x20)
				{
					  Noffset_cont=0;
					  TK_Rebuild();
				}
			}
		}
	}
}
/*************************************************************/
//TK Positive rebuild
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/ 
void TK_Positive_rebuild(void)
{
	S8_T i;
	if(Key_Map==0)
	{
	if(TK_MODE_FLAG)							//RC mode
	{
		for(i=0;i<16;i++)
		{
			if(Sampling_Data [i]<(Baseline_Data[i]*80/100))
			{
				Noffset_cont1++;
				if(Noffset_cont1>=0x10)
				{
					  Noffset_cont1=0;
					  TK_Rebuild();
				}
			}
		}
	}
	else										//RC mode
	{
		for(i=0;i<15;i++)
		{
			if(Sampling_Data [i]>(Baseline_Data[i]*120/100))
			{
				if(i==1)
			{
				if(Sampling_Data [i]>(Baseline_Data[i]*300/100))
				{
					Noffset_cont1++;
				if(Noffset_cont1>=10)
				{
					  Noffset_cont1=0;
					  TK_Rebuild();
				}
				}
			}
			else
			{
				Noffset_cont1++;
				if(Noffset_cont1>=10)
				{
					  Noffset_cont1=0;
					  TK_Rebuild();
				}
			}
			}
		}
	}
	}
	else 
	{
		Noffset_cont1=0;
	}
}

/*************************************************************/
//Force Rebuid
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/ 
void TK_Force_Rebuid(void)
{
     TKEY->TCH_CR1 |= 0x01;
	 while ((TKEY->TCH_CR1 & 0x01));
}
/*************************************************************/
//TK function mode 
//EntryParameter:KeyMode
//KeyMode:FirstKey,Multikey
//ReturnValue:NONE
/*************************************************************/ 
void TK_key_mode(Key_mode_TypeDef KeyMode)
{
	if(KeyMode==FirstKey)TKEY->TCH_CR1 &= ~(0x01ul << 3);
    else if(KeyMode==Multikey)TKEY->TCH_CR1 |= (0x01ul << 3);
}
/*************************************************************/
//Touch Start scan
//EntryParameter:NewState
//NewState:ENABLE DISABLE
//ReturnValue:NONE
/*************************************************************/ 
void TK_Start_Scan(FunctionalStatus NewState)
{
	if(NewState==ENABLE)
	{
		TKEY->TCH_START = 0x01;
		while(!(TKEY->TCH_START & 0x01));			//waiting TK start scan !
	}
    else if(NewState==DISABLE)
	{
		TKEY->TCH_START = 0x00;
		while(TKEY->TCH_START & 0x01);			//waiting TK start scan !
	}
}
/*************************************************************/
//Initial touch CR0
//EntryParameter:
//SCMODE:SCMODE0 / SCMODE1
//TKMODE:TKMODE0 / TKMODE1
//TKSWRST:SWRST0 / SWRST1
//TKDIV:TKPDVI0/1/2/3/4/5
//HYST:TKHYST0 / TKHYST1
//STCFG:STARTCFG0/1/2/3
//HWPROC:HWPROC0 / HWPROC1
//STPENA:STPENA / STPDIS
//ICNT:0X000~0XFFF
//SICNT:0~3
//ReturnValue:value
/*************************************************************/
void TK_Ctrl0_Init(TK_TSCMODE_TypeDef SCMODE,TK_TKMODE_TypeDef TKMODE,TK_DBGEN_TypeDef TKDBG ,U8_T SICNT,
                   TK_TKPDVI_TypeDef TKDIV,TK_TKHYST_TypeDef HYST,TK_STCFG_TypeDef STCFG,
                   TK_HWPROC_TypeDef HWPROC,TK_STPENA_TypeDef STPENA,U16_T ICNT )
{
     TKEY->TCH_CR0 |=SCMODE | TKMODE | TKDBG | (SICNT<<10) | TKDIV | HYST | STCFG | HWPROC | STPENA;
     TKEY->TCH_CR0 = TKEY->TCH_CR0 | (ICNT<<20);
}
/*************************************************************/
//Initial touch CR1
//EntryParameter:
//OFFSET:OFFSET0/1/2/3
//TKFREQ:TKMODE0 / TKMODE1
//TKSWRST:TKFREQ0 / TKFREQ2 /TKFREQ25
//CMPFLT:CMPFLT0/1/2/3
//BLUPDICNT:BLUPDICNT0/1/2/3
//TOSCFDIV:TOSCFDIV0/1/2/3/4/5/6/7/8/9/10/11/12/13/14/15
//KEYSTICKCHK:ENABLE / DISABLE
//_Time:_16s / _32s / _48s / _64s
//KEYDETDEB:KEYDETDEB0/1/2/3
//ICNTSWEN:ENABLE / DISABLE
//BLUPDIS:BASE_EN /BASE_DIS
//BLUPDIS_CYCLE:0X00~0XFF
//ReturnValue:value
/*************************************************************/
void TK_Ctrl1_Init(TK_OFFSETMUL_TypeDef OFFSET,TK_TKFREQ_TypeDef TKFREQ,TK_CMPFLT_TypeDef CMPFLT,
                   TK_BLUPDICNT_TypeDef BLUPDICNT,TK_TOSCFDIV_TypeDef TOSCFDIV,TK_KEYSTICKCHK_TypeDef KEYSTICKCHK,
                   TK_KEYSTICKDUR_TypeDef _Time,TK_KEYDETDEB_TypeDef KEYDETDEB,TK_ICNTSWEN_TypeDef ICNTSWEN,
                   TK_BLUPDIS_TypeDef BLUPDIS,U8_T BLUPDIS_CYCLE)
{
    TKEY->TCH_CR1 |= OFFSET | TKFREQ | CMPFLT | BLUPDICNT | TOSCFDIV |KEYSTICKCHK | _Time |KEYDETDEB | ICNTSWEN | BLUPDIS;
    TKEY->TCH_CR1 = TKEY->TCH_CR1 | (BLUPDIS_CYCLE<<24);
}
/*************************************************************/
//Initial touch HARDWRE0  sample_data>baseline+data
//EntryParameter:
//BLUPD_THR:BLUPD_THR0/1/2/3
//WCO0:BLUPD_WCO0_0/1/2/3
//WCO1:BLUPD_WCO1_0/1/2/3
//DEB0:0~0xF
//DEB1:0X00~0xFF
//ABNFLT:ABNFLT0/1/2/3
//BLUPD_THVAL:0X00~0XFF
//ReturnValue:value
/*************************************************************/
void  TK_Hardware0_Init(TK_BLUPD_THR_TypeDef BLUPD_THR,TK_BLUPD_WCO0_TypeDef WCO0,TK_BLUPD_WCO1_TypeDef WCO1,
                       U8_T DEB0, U8_T DEB1,TK_ABNFLT_TypeDef ABNFLT,U8_T BLUPD_THVAL)
{
    TKEY->TCH_HWPCR0 |= BLUPD_THR | WCO0 | WCO1 | (DEB0<<8) | (DEB1<<12) | ABNFLT | (BLUPD_THVAL<<24);
}
/*************************************************************/
//Initial touch HARDWRE1  sample_data<baseline+data
//EntryParameter:
//BLUPD_THR:BLUPD_THR0/1/2/3
//WCO0:BLUPD_WCO0_0/1/2/3
//WCO1:BLUPD_WCO1_0/1/2/3
//DEB0:0~0xF
//DEB1:0X00~0xFF
//ABNFLT:ABNFLT0/1/2/3
//BLUPD_THVAL:0X00~0XFF
//ReturnValue:value
/*************************************************************/
void  TK_Hardware1_Init(TK_BLUPD_THR_TypeDef BLUPD_THR,TK_BLUPD_WCO0_TypeDef WCO0,TK_BLUPD_WCO1_TypeDef WCO1,
                       U8_T DEB0, U8_T DEB1,TK_ABNFLT_TypeDef ABNFLT,U8_T BLUPD_THVAL)
{
    TKEY->TCH_HWPCR1 |= BLUPD_THR | WCO0 | WCO1 | (DEB0<<8) | (DEB1<<12) | ABNFLT | (BLUPD_THVAL<<24);
}
/*************************************************************/
//TK scan idle pin default status
//EntryParameter:
//DSR_val:0x00000000 all pins as high-impedance
//DSR_val:0x11111111 all pins as output low
//DSR_val:0x22222222 all pins as output high
//DSR_val:0x33333333 all pins as high-impedance
//ReturnValue:value
/*************************************************************/
void TK_Default_IOStatus(U32_T DSR_val )
{
    TKEY->TCH_CHDST = DSR_val;
}
/*************************************************************/
//TK Sensitivity config
//EntryParameter:
//TSCCR_val:0x00000000 all pins chose GSR bit0~bit7(GSR0)
//TSCCR_val:0x55555555 all pins chose GSR bit8~bit15(GSR1)
//TSCCR_val:0xAAAAAAAA all pins chose GSR bit16~bit23(GSR2)
//TSCCR_val:0xFFFFFFFF all pins chose GSR bit24~bit31(GSR3)
//e.g:if TSRx=0x00000001 means TSC0 chose GSR1 and others chose GSR0
//ReturnValue:value
/*************************************************************/
void TK_Sens_Config(U32_T TSRx,U32_T GSR )
{
    TKEY->TCH_TSR = TSRx;
    TKEY->TCH_GSR = GSR;
}
/*************************************************************/
//TK Trigglevel
//EntryParameter:TK_Trigglevel_data[16s]
//ReturnValue:NONE
/*************************************************************/
void TK_Trigglevel_Config(void)
{
	TKEY->TCH_OSCR0|= TK_Trigglevel_data[0];
	TKEY->TCH_OSCR0|=(TK_Trigglevel_data[1])<<8;
	TKEY->TCH_OSCR0|=(TK_Trigglevel_data[2])<<16;
	TKEY->TCH_OSCR0|=(TK_Trigglevel_data[3])<<24;
	
	TKEY->TCH_OSCR1|=TK_Trigglevel_data[4];
	TKEY->TCH_OSCR1|=(TK_Trigglevel_data[5])<<8;
	TKEY->TCH_OSCR1|=(TK_Trigglevel_data[6])<<16;
	TKEY->TCH_OSCR1|=(TK_Trigglevel_data[7])<<24;
	
	TKEY->TCH_OSCR2|=TK_Trigglevel_data[8];
	TKEY->TCH_OSCR2|=(TK_Trigglevel_data[9])<<8;
	TKEY->TCH_OSCR2|=(TK_Trigglevel_data[10])<<16;
	TKEY->TCH_OSCR2|=(TK_Trigglevel_data[11])<<24;
	
	TKEY->TCH_OSCR3|=TK_Trigglevel_data[12];
	TKEY->TCH_OSCR3|=(TK_Trigglevel_data[13])<<8;
	TKEY->TCH_OSCR3|=(TK_Trigglevel_data[14])<<16;
	TKEY->TCH_OSCR3|=(TK_Trigglevel_data[15])<<24;
}
/*************************************************************/
//TK Interrupt condition Config
//EntryParameter:TKCRx
//TKCRx=0x00000000/0x55555555 press interrupt
//TKCRx=0xAAAAAAAA release interrupt
//TKCRx=0xFFFFFFFF press and release both interrupt
//ReturnValue:NONE
/*************************************************************/
void TK_TKCR_Config(U32_T TKCRx)
{
     TKEY->TCH_TKCR=TKCRx;
}
/*************************************************************/
//TK Interrupt Enable Config
//EntryParameter:IMCR(bit31~bit27)
//IMCR bit27~bit31 map interrupt condition
//ReturnValue:NONE
/*************************************************************/
void TK_IMCR_Config(U32_T IMCR)
{
    TKEY->TCH_IMCR=IMCR;
}
/*************************************************************/
//Read sampling data
//EntryParameter:NONE
//ReturnValue:Sampling_Data[16]
/*************************************************************/
void Read_Sampling(void)
{
    U8_T i;
    for (i=0;i<16;i++)
    {
     Sampling_Data[i]=TKEY->TCH_CHxCNT[i];
    }
}
/*************************************************************/
//Read baseline data
//EntryParameter:NONE
//ReturnValue:Baseline_Data
/*************************************************************/
void Read_Baseline(void)
{
    U8_T i;
    for (i=0;i<16;i++)
    {
     Baseline_Data[i]=TKEY->TCH_CHxBL[i];
    }
}
/*************************************************************/
//Read offset data
//EntryParameter:NONE
//ReturnValue:Offset_Data
/*************************************************************/
void Read_Offset(void)
{
    U8_T i;
	if(TK_MODE_FLAG)										//RC Mode
	{
		for (i=0;i<16;i++)
		{
		 Offset_Data[i]=Sampling_Data[i]-Baseline_Data[i];
		}
	}
	else													//EX Mode
	{
		for (i=0;i<16;i++)
		{
		 Offset_Data[i]=Baseline_Data[i]-Sampling_Data[i];
		}
	}
    
}
/*************************************************************/
//Read keymap data
//EntryParameter:NONE
//ReturnValue:Key_Map
/*************************************************************/
void Read_Keymap(void)
{
    Key_Map=TKEY->TCH_TKEYST;
}
/*************************************************************/
//TK Relaxation oscillation counter config
//EntryParameter:
//TSCCR_val:0x00000000 all pins chose TSCDR_val bit0~bit7(CDR0)
//TSCCR_val:0x55555555 all pins chose TSCDR_val bit8~bit15(CDR1)
//TSCCR_val:0xAAAAAAAA all pins chose TSCDR_val bit16~bit23(CDR2)
//TSCCR_val:0xFFFFFFFF all pins chose TSCDR_val bit24~bit31(CDR3)
//e.g:if TSCCR_val=0x00000001 means TSC0 chose CDR1 and others chose CDR0
//ReturnValue:value
/*************************************************************/
void TK_TSCCR_Config(U32_T TSCCR_val,U32_T TSCDR_val )
{
    TKEY->TCH_TSCCR = TSCCR_val;
    TKEY->TCH_TSCDR = TSCDR_val;
}
/*************************************************************/
//TK scan time control
//EntryParameter:SCTDATA 0x0000~0xFFFF
//ReturnValue:value
/*************************************************************/
void TK_SCTCR_Config(U16_T SCTDATA)
{
    TKEY->TCH_SCTCR =SCTDATA;
}
/*************************************************************/
//TK Basedata config
//EntryParameter:base_bit (when bitx=1 enable baseline force update)
//base_val:0x0000~0xFFFF
//ReturnValue:value
/*************************************************************/
void TK_Baseline_Config(U16_T base_bit,U16_T base_val)
{
    TKEY->TCH_BLFUCR |= base_bit | (base_val<<16);
}
/*************************************************************/
//TK0 Interrupt enable
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/
void TK0_Int_Enable(void)
{
    TKEY->TCH_ICR=0xF800FFFF;								//clear tk INT status
	INTC_ISER_WRITE(TKEY0_INT);                             //Enable I2C interrupt
}
/*************************************************************/
//TK0 Interrupt Disable
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/
void TK0_Int_Disable(void)
{
    INTC_ICER_WRITE(TKEY0_INT);                             //Enable I2C interrupt
}
/*************************************************************/
//TK1 Interrupt enable
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/
void TK1_Int_Enable(void)
{
    INTC_ISER_WRITE(TKEY1_INT);                             //Enable I2C interrupt
}
/*************************************************************/
//TK1 Interrupt Disable
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/
void TK1_Int_Disable(void)
{
    INTC_ICER_WRITE(TKEY1_INT);                             //Enable I2C interrupt
}
/*************************************************************/
//TK0 Wake up enable
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/
void TK0_WakeUp_Enable(void)
{
    INTC_IWER_WRITE(TKEY0_INT);    
}
/*************************************************************/
//TK0 Wake up enable
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/
void TK0_WakeUp_Disable(void)
{
    INTC_IWDR_WRITE(TKEY0_INT);    
}
/*************************************************************/
//TK1 Wake up enable
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/
void TK1_WakeUp_Enable(void)
{
    INTC_IWER_WRITE(TKEY1_INT);    
}
/*************************************************************/
//TK1 Wake up enable
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/
void TK1_WakeUp_Disable(void)
{
    INTC_IWDR_WRITE(TKEY1_INT);    
}
/*************************************************************/
//YOUCH KEY GROUP0 Interrupt
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/
void TKEYGRP0IntHandler(void) 
{
    // ISR content ...
	if ((TKEY->TCH_MISR&KEYINT)==KEYINT) 
	{
		TKEY->TCH_ICR = KEYINT;
		//UARTTxByte(UART0,Key_Map>>8&0XFF);
		//UARTTxByte(UART0,Key_Map&0XFF);
	} 
	else if((TKEY->TCH_MISR&HWRST)==HWRST) 
	{
		TKEY->TCH_ICR = HWRST;
		TK_CLK_Ctrl(CLK_ENABLE);
		while (TKEY->TCH_CR0 &(1<<3));
		TK_HardMacro_Ctrl(TK_ENABLE);                                                                                      						//Enable hard macro 
		if(TK_MODE_FLAG)							//RC mode
		{
			TKEY->TCH_CR1 |= 0x01;
			TK_Start_Scan(ENABLE);
		}
		else										//EX mode
		{
			TK_Start_Scan(ENABLE);
			TK_Force_Rebuid();
		}
		
	}
	else if((TKEY->TCH_MISR&SCTOVF)==SCTOVF) 
	{
		TKEY->TCH_ICR = SCTOVF;
	}
	else if((TKEY->TCH_MISR&BLUPD)==BLUPD) 
	{
		TKEY->TCH_ICR = BLUPD;
	}
	else if((TKEY->TCH_MISR&PRCDNE)==PRCDNE) 
	{
		TKEY->TCH_ICR = PRCDNE;
	}
	
	else if((TKEY->TCH_MISR&CH0_DNE)==CH0_DNE) 
	{
		TKEY->TCH_ICR = CH0_DNE;
	}
	else if((TKEY->TCH_MISR&CH1_DNE)==CH1_DNE) 
	{
		TKEY->TCH_ICR = CH1_DNE;
	}
	else if((TKEY->TCH_MISR&CH1_DNE)==CH1_DNE) 
	{
		TKEY->TCH_ICR = CH1_DNE;
	}
	else if((TKEY->TCH_MISR&CH2_DNE)==CH2_DNE) 
	{
		TKEY->TCH_ICR = CH2_DNE;
	}
	else if((TKEY->TCH_MISR&CH3_DNE)==CH3_DNE) 
	{
		TKEY->TCH_ICR = CH3_DNE;
	}
	else if((TKEY->TCH_MISR&CH4_DNE)==CH4_DNE) 
	{
		TKEY->TCH_ICR = CH4_DNE;
	}
	else if((TKEY->TCH_MISR&CH5_DNE)==CH5_DNE) 
	{
		TKEY->TCH_ICR = CH5_DNE;
	}
	else if((TKEY->TCH_MISR&CH6_DNE)==CH6_DNE) 
	{
		TKEY->TCH_ICR = CH6_DNE;
	}
	else if((TKEY->TCH_MISR&CH7_DNE)==CH7_DNE) 
	{
		TKEY->TCH_ICR = CH7_DNE;
	}
	else if((TKEY->TCH_MISR&CH8_DNE)==CH8_DNE) 
	{
		TKEY->TCH_ICR = CH8_DNE;
	}
	else if((TKEY->TCH_MISR&CH9_DNE)==CH9_DNE) 
	{
		TKEY->TCH_ICR = CH9_DNE;
	}
	else if((TKEY->TCH_MISR&CH10_DNE)==CH10_DNE) 
	{
		TKEY->TCH_ICR = CH10_DNE;
	}
	else if((TKEY->TCH_MISR&CH11_DNE)==CH11_DNE) 
	{
		TKEY->TCH_ICR = CH11_DNE;
	}
	else if((TKEY->TCH_MISR&CH12_DNE)==CH12_DNE) 
	{
		TKEY->TCH_ICR = CH12_DNE;
	}
	else if((TKEY->TCH_MISR&CH13_DNE)==CH13_DNE) 
	{
		TKEY->TCH_ICR = CH13_DNE;
	}
	else if((TKEY->TCH_MISR&CH14_DNE)==CH14_DNE) 
	{
		TKEY->TCH_ICR = CH14_DNE;
	}
	else if((TKEY->TCH_MISR&CH15_DNE)==CH15_DNE) 
	{
		TKEY->TCH_ICR = CH15_DNE;
	}
}

/*************************************************************/
//YOUCH KEY GROUP1 Interrupt
//EntryParameter:NONE
//ReturnValue:NONE
/*************************************************************/
void TKEYGRP1IntHandler(void) 
{
    // ISR content ...
}
/*************************************************************/
//Touch Initial
//EntryParameter:TK_x_MODE,TK_share_x
//TK_x_MODE:TK_RC_MODE,TK_EX_MODE
//TK_share_x:TK_share_EN,TK_share_DIS
//ReturnValue:NONE
/*************************************************************/  
void TK_Init(void)
{
#if defined TK_RC_Mode
		TK_MODE_FLAG=1;
        TK_DeInit();   
        TK_IO_Enable(DISLedShare); 
        TK_Ctrl0_Init(SCMODE0,TKMODE0,TKDBGEN,2,TKPDVI2,TKHYST0,STARTCFG1,HWPROC1,STPENA,0Xff); //set CR0 . STARTCFG must not set STARTCFG3
                                                                 
		TK_CH_Enable(); 
		TK_TSCCR_Config(0x00000000,TK_GSR);
		TK_Sens_Config(0x00000000,TK_GSR); 
		TK_Trigglevel_Config();      
		//TKEY->TCH_SCTCR = 0x20;
		
		TK_Hardware0_Init(BLUPD_THR0,BLUPD_WCO1_1,BLUPD_WCO1_1,0X50,0X60,ABNFLT0,10);                                    					 	//set hardware1 postive
		TK_Hardware1_Init(BLUPD_THR0,BLUPD_WCO1_1,BLUPD_WCO1_1,0X50,0X10,ABNFLT0,10);                                     						//set hardware0 negtive
		TK_Ctrl1_Init(OFFSET0,TKFREQ25,CMPFLT2,BLUPDICNT2,TOSCFDIV0,TK_longpress_Enable,_Longress_time,KEYDETDEB2,ICNTSWDIS,BASE_EN,0x00);      //set CR1	
		TK_key_mode(FirstKey);
		             
		TK_CLK_Ctrl(CLK_ENABLE);
		TK_HardMacro_Ctrl(TK_ENABLE);                                                                                      						//Enable hard macro 
		while (TKEY->TCH_CR0 &(1<<3));	
		
		//TK_Default_IOStatus(0x33333333);                                                                                						//IO default status when none scanning
		TK_TKCR_Config(0Xffffffff);                                                                                     						//TK Interrupt condition config . Press/Release                                                                                 
		TK_IMCR_Config(0X18000000);	
		TK0_Int_Enable();																													//enable TK HW vector
		
		TK_Baseline_Config(TK_Channel_EN,0x0000);
		TKEY->TCH_CR1 |= 0x01;
		TK_Start_Scan(ENABLE);																									
#endif

#if defined TK_EX_Mode
		TK_MODE_FLAG=0;
        TK_DeInit();  
        TK_IO_Enable(DISLedShare);
        TK_Ctrl0_Init(SCMODE0,TKMODE1,TKDBGEN,2,TKPDVI2,TKHYST0,STARTCFG1,HWPROC1,STPENA,0Xff);              								 //set CR0 . STARTCFG must not set STARTCFG3

		TK_CH_Enable(); 
		TK_Sens_Config(0x00000000,TK_GSR);  
		TK_Trigglevel_Config();      
		
		TK_Hardware0_Init(BLUPD_THR0,BLUPD_WCO0_1,BLUPD_WCO1_1,0X05,0X32,ABNFLT0,10);                                     					 	//set hardware0 postive
		TK_Hardware1_Init(BLUPD_THR0,BLUPD_WCO0_1,BLUPD_WCO1_3,0X05,0X06,ABNFLT0,10);                                     						//set hardware1 negtive
		TK_Ctrl1_Init(OFFSET0,TKFREQ0,CMPFLT2,BLUPDICNT2,TOSCFDIV0,TK_longpress_Enable,_Longress_time,KEYDETDEB2,ICNTSWDIS,BASE_EN,0x00);      //set CR1	
		TK_key_mode(Multikey);
		
		TK_CLK_Ctrl(CLK_ENABLE);
		TK_HardMacro_Ctrl(TK_ENABLE);                                                                                      						//Enable hard macro 
		while (TKEY->TCH_CR0 &(1<<3));					
									
		//TK_Default_IOStatus(0x33333333);                                                                                						//IO default status when none scanning
		TK_TKCR_Config(0Xffffffff);                                                                                     						//TK Interrupt condition config . Press/Release                                                                                 
		TK_IMCR_Config(0X18000000);	
		TK0_Int_Enable();																														//enable TK HW vector
		
		TK_Baseline_Config(TK_Channel_EN,0x0000);
		TK_Start_Scan(ENABLE);
		TK_Force_Rebuid();
		TK0_WakeUp_Enable();
#endif
}
/******************* (C) COPYRIGHT 2016 APT Chip *****END OF FILE****/



